package com.drcandle.ai.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [SignalHistoryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class DrCandleDatabase : RoomDatabase() {
    abstract fun signalHistoryDao(): SignalHistoryDao

    companion object {
        @Volatile
        private var instance: DrCandleDatabase? = null

        fun getInstance(context: Context): DrCandleDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    DrCandleDatabase::class.java,
                    "dr_candle_ai.db"
                ).build().also { instance = it }
            }
        }
    }
}
