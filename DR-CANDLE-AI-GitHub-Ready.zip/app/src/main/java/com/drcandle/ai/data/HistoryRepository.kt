package com.drcandle.ai.data

import com.drcandle.ai.database.SignalHistoryDao
import com.drcandle.ai.database.SignalHistoryEntity
import com.drcandle.ai.domain.CombinedSignal
import com.drcandle.ai.domain.SignalOutcome
import com.drcandle.ai.domain.SupportedAssets
import kotlinx.coroutines.flow.Flow

class HistoryRepository(
    private val dao: SignalHistoryDao
) {
    val allHistory: Flow<List<SignalHistoryEntity>> = dao.observeAll()

    suspend fun saveSignal(signal: CombinedSignal): Long {
        val asset = SupportedAssets.findBySymbol(signal.assetSymbol)
        val entity = SignalHistoryEntity(
            timestampMs = signal.timestampMs,
            assetSymbol = signal.assetSymbol,
            direction = signal.direction.name,
            confidencePercent = signal.confidencePercent,
            entryPrice = signal.entryPrice,
            priceDecimals = asset.priceDecimals,
            timeframeCode = signal.timeframeCode,
            suggestedExpiryMinutes = signal.suggestedExpiryMinutes,
            trendDirection = signal.trendDirection.label,
            detailedAnalysis = signal.reasoning,
            localSummary = signal.localResult.reasoning,
            geminiSummary = signal.geminiResult.reasoning.ifBlank {
                signal.geminiResult.errorMessage ?: "Gemini unavailable"
            },
            outcome = SignalOutcome.PENDING.name,
            verifiedAtMs = null,
            isFromScreenScanner = signal.isFromScreenScanner
        )
        return dao.insert(entity)
    }

    suspend fun verifyOutcome(id: Long, outcome: SignalOutcome) {
        dao.updateOutcome(id, outcome.name, System.currentTimeMillis())
    }

    suspend fun deleteEntry(id: Long) {
        dao.deleteById(id)
    }

    suspend fun clearAll() {
        dao.clearAll()
    }
}
