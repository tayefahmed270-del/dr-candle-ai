package com.drcandle.ai.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.TranslateAnimation
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.drcandle.ai.data.AppContainer
import com.drcandle.ai.domain.CombinedSignal
import com.drcandle.ai.domain.EngineStatus
import com.drcandle.ai.domain.GeminiAnalysisResult
import com.drcandle.ai.domain.LocalAnalysisResult
import com.drcandle.ai.domain.SignalDirection
import com.drcandle.ai.domain.SupportedAssets
import com.drcandle.ai.domain.Timeframe
import com.drcandle.ai.domain.TrendDirection
import com.drcandle.ai.scanner.ScannerPermissionActivity
import com.drcandle.ai.scanner.ScreenCaptureManager
import com.drcandle.ai.utils.TerminalLogger
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.abs

class FloatingScannerService : Service() {

    companion object {
        const val ACTION_START_OVERLAY = "com.drcandle.ai.action.START_OVERLAY"
        const val ACTION_STOP_OVERLAY = "com.drcandle.ai.action.STOP_OVERLAY"
        const val ACTION_EXECUTE_SCAN = "com.drcandle.ai.action.EXECUTE_SCAN"
        const val ACTION_SCAN_CANCELLED = "com.drcandle.ai.action.SCAN_CANCELLED"

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        private const val CHANNEL_ID = "dr_candle_scanner_channel"
        private const val NOTIFICATION_ID = 7001
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var scanJob: Job? = null

    private lateinit var windowManager: WindowManager
    private lateinit var appContainer: AppContainer
    private lateinit var screenCaptureManager: ScreenCaptureManager

    private var overlayRoot: FrameLayout? = null
    private var collapsedOrb: TextView? = null
    private var expandedPanel: LinearLayout? = null
    private var scanBeamView: View? = null
    private var statusTextView: TextView? = null
    private var signalBadgeView: TextView? = null
    private var detailTextView: TextView? = null
    private var scanButton: Button? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private var isExpanded = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        appContainer = AppContainer.getInstance(applicationContext)
        screenCaptureManager = ScreenCaptureManager(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_OVERLAY -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SCAN_CANCELLED -> {
                setIdleForeground()
                appContainer.updateScannerState {
                    it.copy(isScanning = false, statusText = "Capture permission cancelled", lastError = "User declined screen capture permission.")
                }
                updateOverlayUi("Capture permission cancelled.", SignalDirection.NO_SIGNAL, 0, "Grant screen capture permission to scan.")
                return START_STICKY
            }
            ACTION_EXECUTE_SCAN -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Int.MIN_VALUE)
                @Suppress("DEPRECATION")
                val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }
                if (resultCode != Int.MIN_VALUE && resultData != null) {
                    promoteMediaProjectionForeground()
                    ensureOverlayAttached()
                    executeScreenScan(resultCode, resultData)
                } else {
                    setIdleForeground()
                    ensureOverlayAttached()
                }
                return START_STICKY
            }
            else -> {
                setIdleForeground()
                ensureOverlayAttached()
                return START_STICKY
            }
        }
    }

    private fun setIdleForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        appContainer.updateScannerState { it.copy(isServiceRunning = true) }
    }

    private fun promoteMediaProjectionForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun ensureOverlayAttached() {
        if (overlayRoot != null) return
        if (!Settings.canDrawOverlays(this)) {
            TerminalLogger.err("SCANNER", "SYSTEM_ALERT_WINDOW permission not granted.")
            stopSelf()
            return
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(140)
        }
        layoutParams = params

        val root = FrameLayout(this)

        // 1. Collapsed Floating DR AI Icon
        val orb = TextView(this).apply {
            text = "DR\nAI"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#00FF88"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            paint.isFakeBoldText = true
            val size = dp(58)
            layoutParams = FrameLayout.LayoutParams(size, size)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#EE050A08"))
                setStroke(dp(2), Color.parseColor("#00FF88"))
            }
            elevation = dp(8).toFloat()
        }

        // 2. Expanded HUD Scanner Panel
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = FrameLayout.LayoutParams(dp(264), WindowManager.LayoutParams.WRAP_CONTENT)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#F2070F0B"))
                setStroke(dp(2), Color.parseColor("#00FF88"))
            }
            elevation = dp(12).toFloat()
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleTxt = TextView(this).apply {
            text = "DR CANDLE SCANNER"
            setTextColor(Color.parseColor("#00FF88"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            paint.isFakeBoldText = true
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val minBtn = TextView(this).apply {
            text = " [—] "
            setTextColor(Color.parseColor("#90C8AC"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(dp(6), dp(4), dp(6), dp(4))
            setOnClickListener { toggleExpanded(false) }
        }
        val closeBtn = TextView(this).apply {
            text = " [X] "
            setTextColor(Color.parseColor("#FF4D6D"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(dp(6), dp(4), dp(4), dp(4))
            setOnClickListener { stopSelf() }
        }
        headerRow.addView(titleTxt)
        headerRow.addView(minBtn)
        headerRow.addView(closeBtn)

        // Animated scanning beam container
        val beamContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(10)).apply {
                topMargin = dp(8)
                bottomMargin = dp(8)
            }
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#112219"))
                cornerRadius = dp(5).toFloat()
            }
        }
        val beam = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(dp(72), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#00FF88"))
                cornerRadius = dp(5).toFloat()
            }
            visibility = View.INVISIBLE
        }
        beamContainer.addView(beam)
        scanBeamView = beam

        val statusTv = TextView(this).apply {
            text = "STATUS: READY TO CAPTURE"
            setTextColor(Color.parseColor("#B5E2C8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        }
        statusTextView = statusTv

        val badgeTv = TextView(this).apply {
            text = "NO SIGNAL"
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#E0F7EB"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            paint.isFakeBoldText = true
            setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(6)
            }
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#13281E"))
                cornerRadius = dp(10).toFloat()
                setStroke(dp(1), Color.parseColor("#2A5942"))
            }
        }
        signalBadgeView = badgeTv

        val detailTv = TextView(this).apply {
            text = "Tap SCAN NOW while viewing any trading chart."
            setTextColor(Color.parseColor("#8FB8A2"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            maxLines = 4
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(6)
                bottomMargin = dp(10)
            }
        }
        detailTextView = detailTv

        val btn = Button(this).apply {
            text = "SCAN NOW"
            setTextColor(Color.parseColor("#050A08"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            paint.isFakeBoldText = true
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#00FF88"))
                cornerRadius = dp(10).toFloat()
            }
            setOnClickListener { requestScreenCaptureAndScan() }
        }
        scanButton = btn

        panel.addView(headerRow)
        panel.addView(beamContainer)
        panel.addView(statusTv)
        panel.addView(badgeTv)
        panel.addView(detailTv)
        panel.addView(btn)

        // Touch drag on orb & panel header
        attachDragTouch(orb, params, root) { toggleExpanded(true) }
        attachDragTouch(titleTxt, params, root) { /* no-op on click */ }

        root.addView(orb)
        root.addView(panel)

        collapsedOrb = orb
        expandedPanel = panel
        overlayRoot = root

        windowManager.addView(root, params)
        TerminalLogger.info("SCANNER", "Floating DR AI overlay attached")
    }

    private fun toggleExpanded(expand: Boolean) {
        isExpanded = expand
        collapsedOrb?.visibility = if (expand) View.GONE else View.VISIBLE
        expandedPanel?.visibility = if (expand) View.VISIBLE else View.GONE
    }

    private fun requestScreenCaptureAndScan() {
        if (scanJob?.isActive == true) {
            TerminalLogger.warn("SCANNER", "Scan already in progress; ignoring duplicate tap.")
            return
        }
        val permIntent = Intent(this, ScannerPermissionActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(permIntent)
    }

    private fun executeScreenScan(resultCode: Int, resultData: Intent) {
        if (scanJob?.isActive == true) return
        scanJob = serviceScope.launch {
            toggleExpanded(true)
            startBeamAnimation(true)
            scanButton?.isEnabled = false
            scanButton?.text = "SCANNING..."
            appContainer.updateScannerState {
                it.copy(isScanning = true, statusText = "Capturing chart frame...", lastError = null)
            }
            updateOverlayUi("Capturing chart frame...", SignalDirection.NO_SIGNAL, 0, "Requesting screen buffer...")

            // Briefly hide overlay so our own HUD doesn't occlude the chart screenshot
            overlayRoot?.visibility = View.INVISIBLE
            val captureResult = screenCaptureManager.captureSingleFrameWithRetries(resultCode, resultData)
            overlayRoot?.visibility = View.VISIBLE

            val bitmap = captureResult.getOrElse { err ->
                startBeamAnimation(false)
                scanButton?.isEnabled = true
                scanButton?.text = "SCAN NOW"
                val msg = err.localizedMessage ?: "Screen capture failed"
                appContainer.updateScannerState {
                    it.copy(isScanning = false, statusText = "Capture failed", lastError = msg)
                }
                updateOverlayUi("Capture error", SignalDirection.NO_SIGNAL, 0, msg)
                setIdleForeground()
                return@launch
            }

            try {
                updateOverlayUi("Analyzing chart (Gemini + Local)...", SignalDirection.NO_SIGNAL, 0, "Running Gemini Vision & local candle pixel check...")
                appContainer.updateScannerState {
                    it.copy(statusText = "Running Gemini Vision + Local analysis...")
                }

                val settings = appContainer.settingsRepository.settingsFlow.first()
                val asset = SupportedAssets.findBySymbol(settings.selectedAssetSymbol)
                val tf = Timeframe.fromCode(settings.selectedTimeframeCode)

                val geminiResult = appContainer.geminiAnalysisEngine.analyzeChartScreenshot(
                    bitmap = bitmap,
                    assetLabel = "${asset.symbol} (Screen Capture)",
                    timeframeCode = tf.code,
                    settings = settings
                )
                val localFallback = appContainer.localBitmapChartAnalyzer.analyzeScreenshot(bitmap)

                val finalDirection: SignalDirection
                val finalConfidence: Int
                val finalReasoning: String

                if (geminiResult.status == EngineStatus.READY) {
                    finalDirection = geminiResult.direction
                    finalConfidence = geminiResult.confidencePercent
                    finalReasoning = "[GEMINI VISION] ${geminiResult.reasoning}"
                } else {
                    finalDirection = localFallback.direction
                    finalConfidence = localFallback.confidencePercent
                    finalReasoning = "[LOCAL FALLBACK — Gemini error: ${geminiResult.errorMessage}] ${localFallback.reasoning}"
                }

                if (settings.floatingScannerAutoSave) {
                    val savedSignal = CombinedSignal(
                        assetSymbol = "${asset.symbol} [SCAN]",
                        direction = finalDirection,
                        confidencePercent = finalConfidence,
                        entryPrice = 0.0,
                        suggestedExpiryMinutes = settings.customExpiryMinutes,
                        timeframeCode = tf.code,
                        trendDirection = TrendDirection.SIDEWAYS,
                        reasoning = finalReasoning,
                        timestampMs = System.currentTimeMillis(),
                        localResult = localFallback,
                        geminiResult = geminiResult,
                        dataCandleCount = 0,
                        isFromScreenScanner = true
                    )
                    appContainer.historyRepository.saveSignal(savedSignal)
                }

                appContainer.updateScannerState {
                    it.copy(
                        isScanning = false,
                        statusText = "Scan complete",
                        lastDirection = finalDirection,
                        lastConfidence = finalConfidence,
                        lastReasoning = finalReasoning,
                        lastError = geminiResult.errorMessage,
                        lastScanTimestampMs = System.currentTimeMillis()
                    )
                }
                updateOverlayUi("Scan complete", finalDirection, finalConfidence, finalReasoning)
            } finally {
                bitmap.recycle()
                startBeamAnimation(false)
                scanButton?.isEnabled = true
                scanButton?.text = "SCAN NOW"
                setIdleForeground()
            }
        }
    }

    private fun updateOverlayUi(
        status: String,
        direction: SignalDirection,
        confidence: Int,
        reasoning: String
    ) {
        statusTextView?.text = "STATUS: $status"
        val badgeText = if (direction == SignalDirection.NO_SIGNAL) {
            "NO SIGNAL (${confidence}%)"
        } else {
            "${direction.label} • ${confidence}%"
        }
        signalBadgeView?.text = badgeText
        val colorHex = when (direction) {
            SignalDirection.CALL -> "#00FF88"
            SignalDirection.PUT -> "#FF3366"
            SignalDirection.NO_SIGNAL -> "#FFB800"
        }
        signalBadgeView?.setTextColor(Color.parseColor(colorHex))
        detailTextView?.text = reasoning
    }

    private fun startBeamAnimation(active: Boolean) {
        val beam = scanBeamView ?: return
        beam.clearAnimation()
        if (!active) {
            beam.visibility = View.INVISIBLE
            return
        }
        beam.visibility = View.VISIBLE
        val anim = TranslateAnimation(0f, dp(168).toFloat(), 0f, 0f).apply {
            duration = 900L
            repeatCount = Animation.INFINITE
            repeatMode = Animation.REVERSE
        }
        beam.startAnimation(anim)
        val pulse = AlphaAnimation(0.45f, 1.0f).apply {
            duration = 500L
            repeatCount = Animation.INFINITE
            repeatMode = Animation.REVERSE
        }
        statusTextView?.startAnimation(pulse)
    }

    private fun attachDragTouch(
        target: View,
        params: WindowManager.LayoutParams,
        root: View,
        onTap: () -> Unit
    ) {
        var initX = 0
        var initY = 0
        var downX = 0f
        var downY = 0f
        var moved = false

        target.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = params.x
                    initY = params.y
                    downX = event.rawX
                    downY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    params.x = initX + dx
                    params.y = initY + dy
                    runCatching { windowManager.updateViewLayout(root, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap()
                    true
                }
                else -> false
            }
        }
    }

    private fun buildNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = Intent(this, FloatingScannerService::class.java).apply {
            action = ACTION_STOP_OVERLAY
        }
        val stopPending = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.scanner_notification_title))
            .setContentText(getString(R.string.scanner_notification_text))
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Scanner", stopPending)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.scanner_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.scanner_channel_description)
            }
            nm.createNotificationChannel(channel)
        }
    }

    private fun dp(value: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        value.toFloat(),
        resources.displayMetrics
    ).toInt()

    override fun onDestroy() {
        super.onDestroy()
        scanJob?.cancel()
        serviceScope.cancel()
        overlayRoot?.let { runCatching { windowManager.removeView(it) } }
        overlayRoot = null
        appContainer.updateScannerState { it.copy(isServiceRunning = false, isScanning = false) }
        TerminalLogger.info("SCANNER", "Floating DR AI scanner service stopped")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
