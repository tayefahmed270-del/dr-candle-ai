package com.drcandle.ai.ui.settings

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.drcandle.ai.ai.GeminiAnalysisEngine
import com.drcandle.ai.domain.AppLanguage
import com.drcandle.ai.domain.AppSettings
import com.drcandle.ai.domain.SupportedAssets
import com.drcandle.ai.domain.Timeframe
import com.drcandle.ai.ui.AppStrings
import com.drcandle.ai.ui.theme.CyberCard
import com.drcandle.ai.ui.theme.CyberColors
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    settings: AppSettings,
    diagnostics: DiagnosticsReport,
    strings: AppStrings,
    viewModel: SettingsViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var proxyUrlInput by remember(settings.customGeminiProxyUrl) { mutableStateOf(settings.customGeminiProxyUrl) }
    var geminiKeyInput by remember(settings.customGeminiApiKey) { mutableStateOf(settings.customGeminiApiKey) }
    var twelveDataInput by remember(settings.twelveDataApiKey) { mutableStateOf(settings.twelveDataApiKey) }
    var otcUrlInput by remember(settings.customOtcFeedUrl) { mutableStateOf(settings.customOtcFeedUrl) }
    var showKeys by remember { mutableStateOf(false) }
    var savedToast by remember { mutableStateOf(false) }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.updateNotifications(granted)
    }

    LaunchedEffect(savedToast) {
        if (savedToast) {
            kotlinx.coroutines.delay(2200L)
            savedToast = false
        }
    }

    val tfColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = CyberColors.NeonGreen,
        unfocusedBorderColor = CyberColors.BorderSubtle,
        focusedTextColor = CyberColors.TextPrimary,
        unfocusedTextColor = CyberColors.TextPrimary,
        focusedLabelColor = CyberColors.NeonGreen,
        unfocusedLabelColor = CyberColors.TextSecondary
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            CyberCard(isHighlighted = true, contentPadding = 12.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Settings, contentDescription = null, tint = CyberColors.NeonGreen, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(strings.settingsTitle, style = MaterialTheme.typography.headlineSmall, color = CyberColors.NeonGreen)
                }
            }
        }

        // 1. Gemini AI Configuration
        item {
            CyberCard(contentPadding = 12.dp) {
                Text("GEMINI AI ENGINE", style = MaterialTheme.typography.labelMedium, color = CyberColors.CyberCyan, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Default mode uses Firebase AI Logic + App Check secure backend proxy (no hardcoded API keys). Optionally configure your own proxy URL or Gemini key below.",
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberColors.TextSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))

                Text("Active Gemini Model", style = MaterialTheme.typography.labelSmall, color = CyberColors.TextMuted)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GeminiAnalysisEngine.SUPPORTED_MODELS.forEach { model ->
                        val selected = model == settings.geminiModel
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selected) CyberColors.NeonGreen else CyberColors.ObsidianBg)
                                .border(1.dp, if (selected) CyberColors.NeonGreen else CyberColors.BorderSubtle, RoundedCornerShape(8.dp))
                                .clickable { viewModel.updateGeminiModel(model) }
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = model,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (selected) CyberColors.ObsidianBg else CyberColors.TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = proxyUrlInput,
                    onValueChange = { proxyUrlInput = it },
                    label = { Text("Optional Production Backend Proxy URL") },
                    placeholder = { Text("https://your-proxy.example.com/analyze") },
                    singleLine = true,
                    colors = tfColors,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = geminiKeyInput,
                    onValueChange = { geminiKeyInput = it },
                    label = { Text("Optional Custom Gemini API Key Override") },
                    placeholder = { Text("Leave blank to use Firebase AI Logic") },
                    singleLine = true,
                    visualTransformation = if (showKeys) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showKeys = !showKeys }) {
                            Icon(
                                imageVector = if (showKeys) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "Toggle key visibility",
                                tint = CyberColors.TextSecondary
                            )
                        }
                    },
                    colors = tfColors,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // 2. Market Data API Configuration
        item {
            CyberCard(contentPadding = 12.dp) {
                Text("MARKET DATA API CONFIGURATION", style = MaterialTheme.typography.labelMedium, color = CyberColors.NeonGreen, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Crypto & PAXG Gold stream live from Binance WebSocket without an API key. Add a Twelve Data API key for live Forex/Spot Gold or an authorized OTC endpoint URL.",
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberColors.TextSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = twelveDataInput,
                    onValueChange = { twelveDataInput = it },
                    label = { Text("Twelve Data API Key (Forex / XAU/USD)") },
                    singleLine = true,
                    visualTransformation = if (showKeys) VisualTransformation.None else PasswordVisualTransformation(),
                    colors = tfColors,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = otcUrlInput,
                    onValueChange = { otcUrlInput = it },
                    label = { Text("Authorized OTC Feed URL (Optional)") },
                    placeholder = { Text("https://authorized-otc-feed.example.com/candles") },
                    singleLine = true,
                    colors = tfColors,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        viewModel.saveApiConfigs(proxyUrlInput, geminiKeyInput, twelveDataInput, otcUrlInput)
                        savedToast = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_api_config_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberColors.NeonGreen,
                        contentColor = CyberColors.ObsidianBg
                    )
                ) {
                    Icon(if (savedToast) Icons.Default.CheckCircle else Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (savedToast) "SAVED" else strings.saveConfig, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 3. Asset, Timeframe & Custom Expiry
        item {
            CyberCard(contentPadding = 12.dp) {
                Text("DEFAULT ASSET, TIMEFRAME & EXPIRY", style = MaterialTheme.typography.labelMedium, color = CyberColors.NeonGreen, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SupportedAssets.all.forEach { asset ->
                        val selected = asset.symbol == settings.selectedAssetSymbol
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selected) CyberColors.NeonGreen else CyberColors.ObsidianBg)
                                .border(1.dp, if (selected) CyberColors.NeonGreen else CyberColors.BorderSubtle, RoundedCornerShape(8.dp))
                                .clickable { viewModel.updateAsset(asset.symbol) }
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Text(
                                asset.symbol,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (selected) CyberColors.ObsidianBg else CyberColors.TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Timeframe.entries.forEach { tf ->
                        val selected = tf.code == settings.selectedTimeframeCode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selected) CyberColors.CyberCyan else CyberColors.ObsidianBg)
                                .border(1.dp, if (selected) CyberColors.CyberCyan else CyberColors.BorderSubtle, RoundedCornerShape(8.dp))
                                .clickable { viewModel.updateTimeframe(tf.code) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                tf.code.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (selected) CyberColors.ObsidianBg else CyberColors.TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Custom Expiry", style = MaterialTheme.typography.bodyMedium, color = CyberColors.TextPrimary)
                    Text("${settings.customExpiryMinutes} min", style = MaterialTheme.typography.titleSmall, color = CyberColors.NeonGreen, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = settings.customExpiryMinutes.toFloat(),
                    onValueChange = { viewModel.updateExpiry(it.roundToInt()) },
                    valueRange = 1f..60f,
                    colors = SliderDefaults.colors(
                        thumbColor = CyberColors.NeonGreen,
                        activeTrackColor = CyberColors.NeonGreen
                    )
                )
            }
        }

        // 4. Language, Notifications, Floating Scanner & Theme
        item {
            CyberCard(contentPadding = 12.dp) {
                Text("INTERFACE & PERMISSIONS", style = MaterialTheme.typography.labelMedium, color = CyberColors.NeonGreen, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.languageLabel, style = MaterialTheme.typography.bodyMedium, color = CyberColors.TextPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        AppLanguage.entries.forEach { lang ->
                            val selected = lang == settings.language
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (selected) CyberColors.NeonGreen else CyberColors.ObsidianBg)
                                    .border(1.dp, if (selected) CyberColors.NeonGreen else CyberColors.BorderSubtle, RoundedCornerShape(8.dp))
                                    .clickable { viewModel.updateLanguage(lang) }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    lang.displayName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) CyberColors.ObsidianBg else CyberColors.TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                SettingsToggleRow(
                    title = "Signal Notifications",
                    checked = settings.notificationsEnabled,
                    onCheckedChange = { enable ->
                        if (enable && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            val granted = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.POST_NOTIFICATIONS
                            ) == PackageManager.PERMISSION_GRANTED
                            if (granted) {
                                viewModel.updateNotifications(true)
                            } else {
                                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        } else {
                            viewModel.updateNotifications(enable)
                        }
                    }
                )

                SettingsToggleRow(
                    title = "Auto-Save Floating Scanner Scans",
                    checked = settings.floatingScannerAutoSave,
                    onCheckedChange = viewModel::updateFloatingAutoSave
                )

                SettingsToggleRow(
                    title = "AMOLED Pure Black Dark Theme",
                    checked = settings.pureBlackAmoled,
                    onCheckedChange = viewModel::updatePureBlackAmoled
                )

                val overlayGranted = Settings.canDrawOverlays(context)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (overlayGranted) "Overlay Permission: GRANTED" else "Overlay Permission: REQUIRED",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (overlayGranted) CyberColors.NeonGreen else CyberColors.WarningAmber
                    )
                    if (!overlayGranted) {
                        OutlinedButton(onClick = {
                            context.startActivity(
                                Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                            )
                        }) {
                            Text("GRANT", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        // 5. Data Connection Diagnostics
        item {
            CyberCard(contentPadding = 12.dp) {
                Text("DATA CONNECTION DIAGNOSTICS", style = MaterialTheme.typography.labelMedium, color = CyberColors.CyberCyan, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Market Feed: ${diagnostics.marketStatus}", style = MaterialTheme.typography.bodySmall, color = CyberColors.TextPrimary)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Gemini Routing: ${diagnostics.geminiStatus}", style = MaterialTheme.typography.bodySmall, color = CyberColors.TextSecondary)
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { viewModel.runConnectionDiagnostics() },
                    enabled = !diagnostics.isRunning,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("run_diagnostics_button")
                ) {
                    Icon(Icons.Default.NetworkCheck, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (diagnostics.isRunning) "TESTING..." else strings.testConnection, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.bodyMedium, color = CyberColors.TextPrimary)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = CyberColors.ObsidianBg,
                checkedTrackColor = CyberColors.NeonGreen
            )
        )
    }
}
