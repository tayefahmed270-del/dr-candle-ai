package com.drcandle.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

@Composable
fun DrCandleTheme(
    pureBlackAmoled: Boolean = false,
    content: @Composable () -> Unit
) {
    val bg = if (pureBlackAmoled) CyberColors.AmoledBlack else CyberColors.ObsidianBg
    val surface = if (pureBlackAmoled) CyberColors.AmoledBlack else CyberColors.TerminalSurface
    val card = if (pureBlackAmoled) CyberColors.TerminalSurface else CyberColors.CardSurface

    val colorScheme = darkColorScheme(
        primary = CyberColors.NeonGreen,
        onPrimary = CyberColors.ObsidianBg,
        primaryContainer = CyberColors.ElevatedSurface,
        onPrimaryContainer = CyberColors.NeonGreen,
        secondary = CyberColors.CyberCyan,
        onSecondary = CyberColors.ObsidianBg,
        tertiary = CyberColors.WarningAmber,
        background = bg,
        onBackground = CyberColors.TextPrimary,
        surface = surface,
        onSurface = CyberColors.TextPrimary,
        surfaceVariant = card,
        onSurfaceVariant = CyberColors.TextSecondary,
        error = CyberColors.PutCrimson,
        onError = CyberColors.TextPrimary,
        outline = CyberColors.BorderSubtle
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = DrCandleTypography,
        content = content
    )
}
