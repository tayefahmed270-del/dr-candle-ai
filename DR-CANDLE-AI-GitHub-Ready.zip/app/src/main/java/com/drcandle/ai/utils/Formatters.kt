package com.drcandle.ai.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.pow
import kotlin.math.roundToLong

object Formatters {
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val dateTimeFormat = SimpleDateFormat("MMM dd, HH:mm:ss", Locale.US)

    fun formatPrice(price: Double, decimals: Int): String {
        if (price.isNaN() || price.isInfinite()) return "--"
        val safeDecimals = decimals.coerceIn(0, 6)
        return String.format(Locale.US, "%.${safeDecimals}f", price)
    }

    fun formatPercent(value: Double): String {
        if (value.isNaN() || value.isInfinite()) return "--"
        return String.format(Locale.US, "%.2f%%", value)
    }

    fun formatTime(timestampMs: Long): String {
        if (timestampMs <= 0L) return "--:--:--"
        return timeFormat.format(Date(timestampMs))
    }

    fun formatDateTime(timestampMs: Long): String {
        if (timestampMs <= 0L) return "--"
        return dateTimeFormat.format(Date(timestampMs))
    }

    fun roundTo(value: Double, decimals: Int): Double {
        val factor = 10.0.pow(decimals.coerceIn(0, 6))
        return (value * factor).roundToLong() / factor
    }
}
