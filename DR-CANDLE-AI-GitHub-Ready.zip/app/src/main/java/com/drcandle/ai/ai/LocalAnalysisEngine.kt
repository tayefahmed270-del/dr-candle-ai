package com.drcandle.ai.ai

import com.drcandle.ai.domain.Candle
import com.drcandle.ai.domain.CandlestickPattern
import com.drcandle.ai.domain.EngineStatus
import com.drcandle.ai.domain.LocalAnalysisResult
import com.drcandle.ai.domain.MarketAsset
import com.drcandle.ai.domain.SignalDirection
import com.drcandle.ai.domain.TechnicalIndicators
import com.drcandle.ai.domain.Timeframe
import com.drcandle.ai.domain.TrendDirection
import com.drcandle.ai.domain.VolatilityLevel
import com.drcandle.ai.utils.Formatters
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

class LocalAnalysisEngine {

    fun analyze(
        asset: MarketAsset,
        timeframe: Timeframe,
        candles: List<Candle>
    ): LocalAnalysisResult {
        val startMs = System.currentTimeMillis()
        if (candles.size < 30) {
            return LocalAnalysisResult(
                direction = SignalDirection.NO_SIGNAL,
                confidencePercent = 0,
                indicators = null,
                reasoning = "Insufficient candle history (${candles.size}/30 required) for reliable technical indicator computation.",
                durationMs = (System.currentTimeMillis() - startMs).coerceAtLeast(1L),
                status = EngineStatus.FAILED,
                errorMessage = "Need at least 30 OHLC candles."
            )
        }

        return try {
            val closes = candles.map { it.close }
            val ema9Series = computeEmaSeries(closes, 9)
            val ema21Series = computeEmaSeries(closes, 21)
            val ema9 = ema9Series.last()
            val ema21 = ema21Series.last()

            val rsi14 = computeRsi14(closes)
            val (macdLine, macdSignal, macdHist) = computeMacd(closes)
            val (bbUpperSeries, bbMiddleSeries, bbLowerSeries) = computeBollingerSeries(closes, 20, 2.0)
            val bbUpper = bbUpperSeries.last()
            val bbMiddle = bbMiddleSeries.last()
            val bbLower = bbLowerSeries.last()

            val atr14 = computeAtr14(candles)
            val lastClose = closes.last()
            val volatilityPct = if (lastClose > 0.0) (atr14 / lastClose) * 100.0 else 0.0
            val volatilityLevel = when {
                volatilityPct < 0.08 -> VolatilityLevel.LOW
                volatilityPct < 0.35 -> VolatilityLevel.MODERATE
                volatilityPct < 0.90 -> VolatilityLevel.HIGH
                else -> VolatilityLevel.EXTREME
            }

            val (supports, resistances) = computeSupportResistance(candles)
            val patterns = detectCandlestickPatterns(candles)

            val emaSpreadPct = if (ema21 != 0.0) ((ema9 - ema21) / ema21) * 100.0 else 0.0
            val trendDirection = when {
                emaSpreadPct > 0.03 && lastClose >= ema21 -> TrendDirection.BULLISH
                emaSpreadPct < -0.03 && lastClose <= ema21 -> TrendDirection.BEARISH
                else -> TrendDirection.SIDEWAYS
            }

            // Composite momentum score (-100..+100)
            var score = 0.0
            val reasons = mutableListOf<String>()

            // 1. EMA 9/21 trend & crossover
            if (ema9 > ema21) {
                score += 22.0
                reasons += "EMA9 > EMA21 (bullish alignment)"
            } else if (ema9 < ema21) {
                score -= 22.0
                reasons += "EMA9 < EMA21 (bearish alignment)"
            }

            // Fresh crossover boost
            if (ema9Series.size >= 3 && ema21Series.size >= 3) {
                val prevDiff = ema9Series[ema9Series.lastIndex - 1] - ema21Series[ema21Series.lastIndex - 1]
                val currDiff = ema9 - ema21
                if (prevDiff <= 0 && currDiff > 0) {
                    score += 14.0
                    reasons += "Fresh EMA 9/21 bullish cross"
                } else if (prevDiff >= 0 && currDiff < 0) {
                    score -= 14.0
                    reasons += "Fresh EMA 9/21 bearish cross"
                }
            }

            // 2. RSI 14 momentum & mean reversion
            when {
                rsi14 in 52.0..68.0 -> {
                    score += 14.0
                    reasons += "RSI(14)=${Formatters.formatPercent(rsi14).removeSuffix("%")} bullish momentum"
                }
                rsi14 in 32.0..48.0 -> {
                    score -= 14.0
                    reasons += "RSI(14)=${Formatters.formatPercent(rsi14).removeSuffix("%")} bearish momentum"
                }
                rsi14 < 30.0 -> {
                    score += 16.0
                    reasons += "RSI(14) oversold (${Formatters.formatPrice(rsi14, 1)})"
                }
                rsi14 > 70.0 -> {
                    score -= 16.0
                    reasons += "RSI(14) overbought (${Formatters.formatPrice(rsi14, 1)})"
                }
            }

            // 3. MACD histogram
            if (macdLine > macdSignal && macdHist > 0) {
                score += 18.0
                reasons += "MACD positive histogram"
            } else if (macdLine < macdSignal && macdHist < 0) {
                score -= 18.0
                reasons += "MACD negative histogram"
            }

            // 4. Bollinger Band position
            if (lastClose <= bbLower * 1.001) {
                score += 12.0
                reasons += "Price testing lower Bollinger Band"
            } else if (lastClose >= bbUpper * 0.999) {
                score -= 12.0
                reasons += "Price testing upper Bollinger Band"
            }

            // 5. Candlestick pattern bias
            patterns.forEach { pattern ->
                when (pattern.bias) {
                    SignalDirection.CALL -> {
                        score += 15.0
                        reasons += "${pattern.label} detected"
                    }
                    SignalDirection.PUT -> {
                        score -= 15.0
                        reasons += "${pattern.label} detected"
                    }
                    SignalDirection.NO_SIGNAL -> {
                        reasons += "${pattern.label} (indecision)"
                    }
                }
            }

            val boundedScore = score.coerceIn(-100.0, 100.0)
            val absScore = abs(boundedScore)

            val direction = when {
                boundedScore >= 24.0 -> SignalDirection.CALL
                boundedScore <= -24.0 -> SignalDirection.PUT
                else -> SignalDirection.NO_SIGNAL
            }

            val confidence = when (direction) {
                SignalDirection.NO_SIGNAL -> (40 - (absScore / 2)).roundToInt().coerceIn(20, 48)
                else -> (50 + (absScore * 0.42)).roundToInt().coerceIn(52, 92)
            }

            val indicators = TechnicalIndicators(
                ema9 = ema9,
                ema21 = ema21,
                ema9Series = ema9Series,
                ema21Series = ema21Series,
                rsi14 = rsi14,
                macdLine = macdLine,
                macdSignal = macdSignal,
                macdHistogram = macdHist,
                bbUpper = bbUpper,
                bbMiddle = bbMiddle,
                bbLower = bbLower,
                bbUpperSeries = bbUpperSeries,
                bbLowerSeries = bbLowerSeries,
                atr14 = atr14,
                volatilityPercent = volatilityPct,
                volatilityLevel = volatilityLevel,
                momentumScore = boundedScore,
                trendDirection = trendDirection,
                supportLevels = supports,
                resistanceLevels = resistances,
                detectedPatterns = patterns
            )

            val summary = if (reasons.isEmpty()) {
                "Mixed indicator readings on ${asset.symbol} (${timeframe.code}); no clear directional confluence."
            } else {
                reasons.joinToString(" • ")
            }

            LocalAnalysisResult(
                direction = direction,
                confidencePercent = confidence,
                indicators = indicators,
                reasoning = summary,
                durationMs = (System.currentTimeMillis() - startMs).coerceAtLeast(1L),
                status = EngineStatus.READY
            )
        } catch (e: Exception) {
            LocalAnalysisResult(
                direction = SignalDirection.NO_SIGNAL,
                confidencePercent = 0,
                indicators = null,
                reasoning = "Local analysis error: ${e.localizedMessage}",
                durationMs = (System.currentTimeMillis() - startMs).coerceAtLeast(1L),
                status = EngineStatus.FAILED,
                errorMessage = e.localizedMessage
            )
        }
    }

    private fun computeEmaSeries(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val k = 2.0 / (period + 1)
        val result = ArrayList<Double>(values.size)
        var ema = values.first()
        result.add(ema)
        for (i in 1 until values.size) {
            ema = values[i] * k + ema * (1.0 - k)
            result.add(ema)
        }
        return result
    }

    private fun computeRsi14(closes: List<Double>, period: Int = 14): Double {
        if (closes.size <= period) return 50.0
        var gainSum = 0.0
        var lossSum = 0.0
        for (i in 1..period) {
            val diff = closes[i] - closes[i - 1]
            if (diff >= 0) gainSum += diff else lossSum += -diff
        }
        var avgGain = gainSum / period
        var avgLoss = lossSum / period
        for (i in (period + 1) until closes.size) {
            val diff = closes[i] - closes[i - 1]
            val gain = if (diff > 0) diff else 0.0
            val loss = if (diff < 0) -diff else 0.0
            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period
        }
        if (avgLoss == 0.0) return 100.0
        val rs = avgGain / avgLoss
        return 100.0 - (100.0 / (1.0 + rs))
    }

    private fun computeMacd(closes: List<Double>): Triple<Double, Double, Double> {
        val ema12 = computeEmaSeries(closes, 12)
        val ema26 = computeEmaSeries(closes, 26)
        val macdSeries = ema12.indices.map { i -> ema12[i] - ema26[i] }
        val signalSeries = computeEmaSeries(macdSeries, 9)
        val macd = macdSeries.last()
        val signal = signalSeries.last()
        return Triple(macd, signal, macd - signal)
    }

    private fun computeBollingerSeries(
        closes: List<Double>,
        period: Int = 20,
        stdDevMult: Double = 2.0
    ): Triple<List<Double>, List<Double>, List<Double>> {
        val upper = ArrayList<Double>(closes.size)
        val middle = ArrayList<Double>(closes.size)
        val lower = ArrayList<Double>(closes.size)

        for (i in closes.indices) {
            val start = max(0, i - period + 1)
            val window = closes.subList(start, i + 1)
            val mean = window.average()
            val variance = window.sumOf { (it - mean).pow(2) } / window.size
            val sd = sqrt(variance)
            middle.add(mean)
            upper.add(mean + stdDevMult * sd)
            lower.add(mean - stdDevMult * sd)
        }
        return Triple(upper, middle, lower)
    }

    private fun computeAtr14(candles: List<Candle>, period: Int = 14): Double {
        if (candles.size < 2) return 0.0
        val trs = ArrayList<Double>(candles.size - 1)
        for (i in 1 until candles.size) {
            val curr = candles[i]
            val prevClose = candles[i - 1].close
            val tr = max(
                curr.high - curr.low,
                max(abs(curr.high - prevClose), abs(curr.low - prevClose))
            )
            trs.add(tr)
        }
        val slice = trs.takeLast(period)
        return if (slice.isEmpty()) 0.0 else slice.average()
    }

    private fun computeSupportResistance(candles: List<Candle>): Pair<List<Double>, List<Double>> {
        val recent = candles.takeLast(60)
        if (recent.size < 7) return emptyList<Double>() to emptyList()

        val swingLows = mutableListOf<Double>()
        val swingHighs = mutableListOf<Double>()

        for (i in 2 until recent.size - 2) {
            val c = recent[i]
            if (c.low <= recent[i - 1].low && c.low <= recent[i - 2].low &&
                c.low <= recent[i + 1].low && c.low <= recent[i + 2].low
            ) {
                swingLows += c.low
            }
            if (c.high >= recent[i - 1].high && c.high >= recent[i - 2].high &&
                c.high >= recent[i + 1].high && c.high >= recent[i + 2].high
            ) {
                swingHighs += c.high
            }
        }

        val lastPrice = recent.last().close
        val supports = clusterLevels(swingLows.filter { it <= lastPrice }).takeLast(2)
        val resistances = clusterLevels(swingHighs.filter { it >= lastPrice }).take(2)
        return supports to resistances
    }

    private fun clusterLevels(levels: List<Double>): List<Double> {
        if (levels.isEmpty()) return emptyList()
        val sorted = levels.sorted()
        val clustered = mutableListOf<Double>()
        for (lvl in sorted) {
            val last = clustered.lastOrNull()
            if (last == null || abs(lvl - last) / max(last, 1e-9) > 0.0015) {
                clustered.add(lvl)
            } else {
                clustered[clustered.lastIndex] = (last + lvl) / 2.0
            }
        }
        return clustered
    }

    private fun detectCandlestickPatterns(candles: List<Candle>): List<CandlestickPattern> {
        if (candles.size < 3) return emptyList()
        val found = mutableListOf<CandlestickPattern>()
        // Analyze the most recent closed candle (or second-to-last if last is still forming)
        val idx = if (!candles.last().isClosed && candles.size >= 4) candles.lastIndex - 1 else candles.lastIndex
        val c = candles[idx]
        val prev = candles[idx - 1]
        val prev2 = candles[idx - 2]

        val body = abs(c.close - c.open)
        val range = (c.high - c.low).coerceAtLeast(1e-9)
        val upperWick = c.high - max(c.open, c.close)
        val lowerWick = min(c.open, c.close) - c.low
        val isBullish = c.close > c.open
        val isBearish = c.close < c.open

        val prevBody = abs(prev.close - prev.open)
        val prevBullish = prev.close > prev.open
        val prevBearish = prev.close < prev.open

        // 1. Doji
        if (body <= range * 0.12) {
            found += CandlestickPattern.DOJI
        }

        // 2. Hammer & Bullish Pin Bar
        if (lowerWick >= body * 2.0 && upperWick <= body * 0.6 && body > 0.0) {
            if (lowerWick >= range * 0.6) {
                found += CandlestickPattern.BULLISH_PIN_BAR
            } else {
                found += CandlestickPattern.HAMMER
            }
        }

        // 3. Shooting Star & Bearish Pin Bar
        if (upperWick >= body * 2.0 && lowerWick <= body * 0.6 && body > 0.0) {
            if (upperWick >= range * 0.6) {
                found += CandlestickPattern.BEARISH_PIN_BAR
            } else {
                found += CandlestickPattern.SHOOTING_STAR
            }
        }

        // 4. Engulfing
        if (isBullish && prevBearish && c.open <= prev.close && c.close >= prev.open && body > prevBody) {
            found += CandlestickPattern.BULLISH_ENGULFING
        } else if (isBearish && prevBullish && c.open >= prev.close && c.close <= prev.open && body > prevBody) {
            found += CandlestickPattern.BEARISH_ENGULFING
        }

        // 5. Morning Star (3-candle bullish reversal)
        val prev2Body = abs(prev2.close - prev2.open)
        val prev2Range = (prev2.high - prev2.low).coerceAtLeast(1e-9)
        val prevRange = (prev.high - prev.low).coerceAtLeast(1e-9)
        if (prev2.close < prev2.open && prev2Body > prev2Range * 0.45 &&
            prevBody <= prevRange * 0.3 &&
            isBullish && c.close > (prev2.open + prev2.close) / 2.0
        ) {
            found += CandlestickPattern.MORNING_STAR
        }

        // 6. Evening Star (3-candle bearish reversal)
        if (prev2.close > prev2.open && prev2Body > prev2Range * 0.45 &&
            prevBody <= prevRange * 0.3 &&
            isBearish && c.close < (prev2.open + prev2.close) / 2.0
        ) {
            found += CandlestickPattern.EVENING_STAR
        }

        return found.distinct()
    }
}
