package com.drcandle.ai.ai

import com.drcandle.ai.domain.AppSettings
import com.drcandle.ai.domain.Candle
import com.drcandle.ai.domain.CombinedSignal
import com.drcandle.ai.domain.EngineStatus
import com.drcandle.ai.domain.MarketAsset
import com.drcandle.ai.domain.SignalDirection
import com.drcandle.ai.domain.Timeframe
import com.drcandle.ai.domain.TrendDirection
import com.drcandle.ai.utils.TerminalLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlin.math.roundToInt

class CombinedAnalysisEngine(
    private val localEngine: LocalAnalysisEngine,
    private val geminiEngine: GeminiAnalysisEngine
) {
    suspend fun analyzeConcurrently(
        asset: MarketAsset,
        timeframe: Timeframe,
        candles: List<Candle>,
        settings: AppSettings
    ): CombinedSignal = coroutineScope {
        TerminalLogger.ai("DUAL_AI", "Dispatching concurrent Local + Gemini analysis on ${candles.size} candles (${asset.symbol} ${timeframe.code})")

        val localDeferred = async(Dispatchers.Default) {
            localEngine.analyze(asset, timeframe, candles)
        }

        val geminiDeferred = if (candles.size >= 30) {
            async(Dispatchers.IO) {
                geminiEngine.analyzeMarketData(
                    asset = asset,
                    timeframe = timeframe,
                    candles = candles,
                    indicators = null,
                    settings = settings
                )
            }
        } else {
            null
        }

        val localResult = localDeferred.await()
        val geminiResult = geminiDeferred?.await() ?: com.drcandle.ai.domain.GeminiAnalysisResult(
            direction = SignalDirection.NO_SIGNAL,
            confidencePercent = 0,
            trendAnalysis = "Insufficient candles",
            patternRecognition = "Skipped",
            indicatorInterpretation = "Skipped",
            reasoning = "Skipped Gemini call because market feed has fewer than 30 candles.",
            modelUsed = settings.geminiModel,
            durationMs = 0L,
            status = EngineStatus.FAILED,
            errorMessage = "Insufficient valid market candles (${candles.size}/30)."
        )

        val finalDirection: SignalDirection
        val finalConfidence: Int
        val combinedReasoning: String

        val entryPrice = candles.lastOrNull()?.close ?: 0.0
        val trend = localResult.indicators?.trendDirection ?: TrendDirection.INSUFFICIENT_DATA

        when {
            localResult.status == EngineStatus.FAILED || candles.size < 30 -> {
                finalDirection = SignalDirection.NO_SIGNAL
                finalConfidence = 0
                combinedReasoning = "Insufficient valid market data (${candles.size} candles). No signal generated."
            }
            geminiResult.status == EngineStatus.READY -> {
                when {
                    localResult.direction == geminiResult.direction -> {
                        finalDirection = localResult.direction
                        finalConfidence = ((localResult.confidencePercent * 0.45) + (geminiResult.confidencePercent * 0.55))
                            .roundToInt()
                            .coerceIn(0, 94)
                        combinedReasoning = "[CONFLUENCE: BOTH ENGINES AGREE] ${geminiResult.reasoning} | Local: ${localResult.reasoning}"
                    }
                    localResult.direction != SignalDirection.NO_SIGNAL &&
                        geminiResult.direction != SignalDirection.NO_SIGNAL -> {
                        // Direct conflict between engines -> disciplined NO SIGNAL
                        finalDirection = SignalDirection.NO_SIGNAL
                        finalConfidence = 35
                        combinedReasoning = "[ENGINE CONFLICT -> NO SIGNAL] Local suggested ${localResult.direction.label} (${localResult.confidencePercent}%) while Gemini suggested ${geminiResult.direction.label} (${geminiResult.confidencePercent}%). ${geminiResult.reasoning}"
                    }
                    geminiResult.direction != SignalDirection.NO_SIGNAL && geminiResult.confidencePercent >= 68 -> {
                        finalDirection = geminiResult.direction
                        finalConfidence = ((localResult.confidencePercent * 0.35) + (geminiResult.confidencePercent * 0.65))
                            .roundToInt()
                            .coerceIn(50, 82)
                        combinedReasoning = "[GEMINI LEAD] ${geminiResult.reasoning} | Local note: ${localResult.reasoning}"
                    }
                    localResult.direction != SignalDirection.NO_SIGNAL && localResult.confidencePercent >= 70 -> {
                        finalDirection = localResult.direction
                        finalConfidence = ((localResult.confidencePercent * 0.65) + (geminiResult.confidencePercent * 0.35))
                            .roundToInt()
                            .coerceIn(50, 80)
                        combinedReasoning = "[LOCAL LEAD] ${localResult.reasoning} | Gemini note: ${geminiResult.reasoning}"
                    }
                    else -> {
                        finalDirection = SignalDirection.NO_SIGNAL
                        finalConfidence = ((localResult.confidencePercent + geminiResult.confidencePercent) / 2).coerceIn(20, 49)
                        combinedReasoning = "Neither engine detected high-conviction setup. ${geminiResult.reasoning}"
                    }
                }
            }
            else -> {
                // Gemini failed — report Gemini failure honestly, evaluate local cautiously
                finalDirection = if (localResult.confidencePercent >= 68) localResult.direction else SignalDirection.NO_SIGNAL
                finalConfidence = if (finalDirection == SignalDirection.NO_SIGNAL) 30 else (localResult.confidencePercent - 10).coerceIn(50, 78)
                combinedReasoning = "[LOCAL ONLY — GEMINI FAILED: ${geminiResult.errorMessage}] ${localResult.reasoning}"
            }
        }

        TerminalLogger.ai(
            "COMBINED",
            "Final Signal: ${finalDirection.label} @ $entryPrice | Confidence=${finalConfidence}% | Local=${localResult.status.label} | Gemini=${geminiResult.status.label}"
        )

        CombinedSignal(
            assetSymbol = asset.symbol,
            direction = finalDirection,
            confidencePercent = finalConfidence,
            entryPrice = entryPrice,
            suggestedExpiryMinutes = settings.customExpiryMinutes.coerceAtLeast(timeframe.defaultExpiryMinutes),
            timeframeCode = timeframe.code,
            trendDirection = trend,
            reasoning = combinedReasoning,
            timestampMs = System.currentTimeMillis(),
            localResult = localResult,
            geminiResult = geminiResult,
            dataCandleCount = candles.size,
            isFromScreenScanner = false
        )
    }
}
