package com.drcandle.ai.market

import com.drcandle.ai.domain.AppSettings
import com.drcandle.ai.domain.AssetCategory
import com.drcandle.ai.domain.Candle
import com.drcandle.ai.domain.MarketAsset
import com.drcandle.ai.domain.MarketFeedState
import com.drcandle.ai.domain.Timeframe
import com.drcandle.ai.network.NetworkModule
import com.drcandle.ai.utils.TerminalLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

class TwelveDataMarketDataProvider : MarketDataProvider {
    override val providerId: String = "twelvedata_rest"
    override val displayName: String = "Twelve Data Market API"
    override val supportsWebSocket: Boolean = false

    private val dateFormats = listOf(
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") },
        SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
    )

    override fun supports(asset: MarketAsset, settings: AppSettings): Boolean =
        !asset.isOtc && (asset.category == AssetCategory.FOREX || asset.category == AssetCategory.GOLD) && asset.twelveDataSymbol != null

    override suspend fun fetchHistoricalCandles(
        asset: MarketAsset,
        timeframe: Timeframe,
        limit: Int,
        settings: AppSettings
    ): Result<Pair<List<Candle>, Long>> = withContext(Dispatchers.IO) {
        val apiKey = settings.twelveDataApiKey.trim()
        if (apiKey.isEmpty()) {
            return@withContext Result.failure(
                IllegalStateException("Twelve Data API key required for live ${asset.symbol} candles. Configure it in Settings or select Crypto / PAXG Gold.")
            )
        }
        val symbol = asset.twelveDataSymbol
            ?: return@withContext Result.failure(IllegalArgumentException("No Twelve Data symbol for ${asset.symbol}"))

        val startMs = System.currentTimeMillis()
        try {
            val response = NetworkModule.twelveDataApi.getTimeSeries(
                symbol = symbol,
                interval = timeframe.twelveDataInterval,
                outputSize = limit.coerceIn(30, 200),
                apiKey = apiKey
            )
            val latency = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
            if (!response.isSuccessful) {
                val err = "HTTP ${response.code()} ${response.message()}"
                TerminalLogger.err("TWELVEDATA", "REST error for $symbol: $err")
                return@withContext Result.failure(IllegalStateException(err))
            }

            val body = response.body().orEmpty()
            val status = body["status"]?.toString()
            if (status == "error") {
                val message = body["message"]?.toString() ?: "Twelve Data API error"
                TerminalLogger.err("TWELVEDATA", message)
                return@withContext Result.failure(IllegalStateException(message))
            }

            @Suppress("UNCHECKED_CAST")
            val values = body["values"] as? List<Map<String, Any>> ?: emptyList()
            val candles = values.mapNotNull { row ->
                try {
                    val dt = row["datetime"]?.toString() ?: return@mapNotNull null
                    val ts = parseUtcTime(dt)
                    Candle(
                        openTimeMs = ts,
                        open = row["open"].toString().toDouble(),
                        high = row["high"].toString().toDouble(),
                        low = row["low"].toString().toDouble(),
                        close = row["close"].toString().toDouble(),
                        volume = row["volume"]?.toString()?.toDoubleOrNull() ?: 0.0,
                        isClosed = true
                    )
                } catch (_: Exception) {
                    null
                }
            }.sortedBy { it.openTimeMs }

            if (candles.isEmpty()) {
                return@withContext Result.failure(IllegalStateException("No OHLC candles returned for $symbol"))
            }

            TerminalLogger.net("TWELVEDATA", "Loaded ${candles.size} ${timeframe.code} candles for $symbol (${latency}ms)")
            Result.success(candles to latency)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            TerminalLogger.err("TWELVEDATA", "Network error: ${e.localizedMessage}")
            Result.failure(e)
        }
    }

    override fun streamMarketData(
        asset: MarketAsset,
        timeframe: Timeframe,
        settings: AppSettings
    ): Flow<MarketStreamEvent> = flow {
        val apiKey = settings.twelveDataApiKey.trim()
        if (apiKey.isEmpty()) {
            val msg = "Forex/Spot Gold (${asset.symbol}) requires a genuine market data API key (Twelve Data) in Settings. No simulated prices are generated."
            TerminalLogger.warn("MARKET", msg)
            emit(MarketStreamEvent.StateChanged(MarketFeedState.UnsupportedSource(displayName, msg)))
            return@flow
        }

        emit(MarketStreamEvent.StateChanged(MarketFeedState.Connecting(displayName)))
        while (currentCoroutineContext().isActive) {
            val res = fetchHistoricalCandles(asset, timeframe, 100, settings)
            res.onSuccess { (candles, latency) ->
                emit(MarketStreamEvent.HistoricalSnapshot(candles, latency))
                emit(
                    MarketStreamEvent.StateChanged(
                        MarketFeedState.LiveRestFallback(
                            sourceName = displayName,
                            note = "REST polling every 15s (rate-limit safe)",
                            lastTickMs = System.currentTimeMillis()
                        )
                    )
                )
            }.onFailure { err ->
                emit(
                    MarketStreamEvent.StateChanged(
                        MarketFeedState.Error(displayName, err.localizedMessage ?: "Market feed error")
                    )
                )
            }
            delay(15_000L)
        }
    }.flowOn(Dispatchers.IO)

    private fun parseUtcTime(raw: String): Long {
        for (fmt in dateFormats) {
            try {
                val d = fmt.parse(raw)
                if (d != null) return d.time
            } catch (_: Exception) {
            }
        }
        return System.currentTimeMillis()
    }
}
