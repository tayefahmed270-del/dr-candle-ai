package com.drcandle.ai.ui.theme

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.drcandle.ai.domain.Candle
import com.drcandle.ai.domain.TechnicalIndicators
import com.drcandle.ai.utils.Formatters
import kotlin.math.max
import kotlin.math.min

@Composable
fun CyberCard(
    modifier: Modifier = Modifier,
    glowColor: Color = CyberColors.NeonGreen,
    isHighlighted: Boolean = false,
    contentPadding: Dp = 14.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val borderBrush = Brush.linearGradient(
        colors = if (isHighlighted) {
            listOf(glowColor, glowColor.copy(alpha = 0.35f), glowColor)
        } else {
            listOf(glowColor.copy(alpha = 0.45f), CyberColors.BorderSubtle, glowColor.copy(alpha = 0.25f))
        }
    )

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.94f)
        ),
        border = BorderStroke(if (isHighlighted) 1.5.dp else 1.dp, borderBrush)
    ) {
        Column(
            modifier = Modifier.padding(contentPadding),
            content = content
        )
    }
}

@Composable
fun AnimatedCyberLogo(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "logo_pulse")
    val sweepAngle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(3600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radar_sweep"
    )
    val pulseAlpha by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "core_pulse"
    )

    Box(
        modifier = modifier.size(42.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val radius = size.minDimension / 2f
            val center = Offset(size.width / 2f, size.height / 2f)

            drawCircle(
                color = CyberColors.NeonGreen.copy(alpha = 0.16f),
                radius = radius
            )
            drawCircle(
                color = CyberColors.NeonGreen.copy(alpha = 0.7f),
                radius = radius - 2f,
                style = Stroke(width = 2.5f)
            )
            drawArc(
                color = CyberColors.NeonGreen.copy(alpha = pulseAlpha),
                startAngle = sweepAngle,
                sweepAngle = 70f,
                useCenter = false,
                style = Stroke(width = 4f)
            )

            // Mini glowing candlestick silhouette inside emblem
            val barW = size.width * 0.10f
            drawLine(
                color = CyberColors.NeonGreen,
                start = Offset(center.x - barW * 1.8f, center.y - radius * 0.45f),
                end = Offset(center.x - barW * 1.8f, center.y + radius * 0.45f),
                strokeWidth = 2f
            )
            drawRect(
                color = CyberColors.NeonGreen,
                topLeft = Offset(center.x - barW * 2.3f, center.y - radius * 0.18f),
                size = Size(barW, radius * 0.42f)
            )

            drawLine(
                color = CyberColors.CyberCyan,
                start = Offset(center.x, center.y - radius * 0.55f),
                end = Offset(center.x, center.y + radius * 0.35f),
                strokeWidth = 2f
            )
            drawRect(
                color = CyberColors.CyberCyan,
                topLeft = Offset(center.x - barW * 0.5f, center.y - radius * 0.36f),
                size = Size(barW, radius * 0.46f)
            )

            drawLine(
                color = CyberColors.PutCrimson,
                start = Offset(center.x + barW * 1.8f, center.y - radius * 0.32f),
                end = Offset(center.x + barW * 1.8f, center.y + radius * 0.48f),
                strokeWidth = 2f
            )
            drawRect(
                color = CyberColors.PutCrimson,
                topLeft = Offset(center.x + barW * 1.3f, center.y - radius * 0.12f),
                size = Size(barW, radius * 0.34f)
            )
        }
    }
}

@Composable
fun ScanningBeamBar(
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "scan_beam")
    val beamPos by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "beam_x"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(CyberColors.GridLine)
    ) {
        if (isActive) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val beamWidth = size.width * 0.32f
                val startX = (size.width - beamWidth) * beamPos
                drawRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            CyberColors.NeonGreen,
                            CyberColors.CyberCyan,
                            Color.Transparent
                        ),
                        startX = startX,
                        endX = startX + beamWidth
                    ),
                    topLeft = Offset(startX, 0f),
                    size = Size(beamWidth, size.height)
                )
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.18f)
                    .height(6.dp)
                    .background(CyberColors.NeonGreen.copy(alpha = 0.35f))
            )
        }
    }
}

@Composable
fun StatusLedPill(
    label: String,
    color: Color,
    isPulsing: Boolean = false,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "led")
    val alpha by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "led_alpha"
    )
    val dotAlpha = if (isPulsing) alpha else 1f

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.55f), RoundedCornerShape(50))
            .padding(horizontal = 9.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = dotAlpha))
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}

@Composable
fun CandlestickChartCanvas(
    candles: List<Candle>,
    indicators: TechnicalIndicators?,
    priceDecimals: Int,
    isScanning: Boolean,
    modifier: Modifier = Modifier
) {
    val visibleCandles = candles.takeLast(48)
    val transition = rememberInfiniteTransition(label = "chart_beam")
    val scanRatio by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scan_line"
    )

    if (visibleCandles.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(220.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(CyberColors.ObsidianBg)
                .border(1.dp, CyberColors.BorderSubtle, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "AWAITING GENUINE MARKET CANDLES...",
                style = MaterialTheme.typography.labelMedium,
                color = CyberColors.TextSecondary
            )
        }
        return
    }

    val rawMin = visibleCandles.minOf { it.low }
    val rawMax = visibleCandles.maxOf { it.high }
    val pad = ((rawMax - rawMin) * 0.12).coerceAtLeast(1e-6)
    val minPrice = rawMin - pad
    val maxPrice = rawMax + pad
    val priceSpan = (maxPrice - minPrice).coerceAtLeast(1e-9)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(235.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(CyberColors.ObsidianBg)
            .border(1.dp, CyberColors.BorderSubtle, RoundedCornerShape(10.dp))
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 6.dp, end = 64.dp, top = 12.dp, bottom = 12.dp)
        ) {
            val w = size.width
            val h = size.height

            fun priceToY(p: Double): Float {
                val ratio = ((p - minPrice) / priceSpan).toFloat()
                return h - (ratio * h)
            }

            // 1. Cyber Grid lines
            for (g in 0..4) {
                val y = (h / 4f) * g
                drawLine(
                    color = CyberColors.GridLine,
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1f
                )
            }

            val count = visibleCandles.size
            val slotW = w / count.toFloat()
            val bodyW = max(3f, slotW * 0.62f)

            // 2. Bollinger Bands
            if (indicators != null && indicators.bbUpperSeries.size >= count) {
                val bbUp = indicators.bbUpperSeries.takeLast(count)
                val bbLow = indicators.bbLowerSeries.takeLast(count)
                val upPath = Path()
                val lowPath = Path()
                bbUp.forEachIndexed { idx, v ->
                    val x = idx * slotW + slotW / 2f
                    val y = priceToY(v)
                    if (idx == 0) upPath.moveTo(x, y) else upPath.lineTo(x, y)
                }
                bbLow.forEachIndexed { idx, v ->
                    val x = idx * slotW + slotW / 2f
                    val y = priceToY(v)
                    if (idx == 0) lowPath.moveTo(x, y) else lowPath.lineTo(x, y)
                }
                drawPath(upPath, color = CyberColors.NeonGreen.copy(alpha = 0.25f), style = Stroke(width = 1.4f))
                drawPath(lowPath, color = CyberColors.NeonGreen.copy(alpha = 0.25f), style = Stroke(width = 1.4f))
            }

            // 3. Support & Resistance dashed lines
            indicators?.supportLevels?.forEach { sup ->
                if (sup in minPrice..maxPrice) {
                    val y = priceToY(sup)
                    drawLine(
                        color = CyberColors.NeonGreen.copy(alpha = 0.55f),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1.5f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
                    )
                }
            }
            indicators?.resistanceLevels?.forEach { res ->
                if (res in minPrice..maxPrice) {
                    val y = priceToY(res)
                    drawLine(
                        color = CyberColors.PutCrimson.copy(alpha = 0.55f),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1.5f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
                    )
                }
            }

            // 4. Candlesticks
            visibleCandles.forEachIndexed { index, candle ->
                val centerX = index * slotW + slotW / 2f
                val isBull = candle.close >= candle.open
                val candleColor = if (isBull) CyberColors.NeonGreen else CyberColors.PutCrimson

                val yHigh = priceToY(candle.high)
                val yLow = priceToY(candle.low)
                val yOpen = priceToY(candle.open)
                val yClose = priceToY(candle.close)

                drawLine(
                    color = candleColor.copy(alpha = 0.85f),
                    start = Offset(centerX, yHigh),
                    end = Offset(centerX, yLow),
                    strokeWidth = 2f
                )

                val top = min(yOpen, yClose)
                val bottom = max(yOpen, yClose)
                val rectHeight = max(3f, bottom - top)
                drawRect(
                    color = candleColor,
                    topLeft = Offset(centerX - bodyW / 2f, top),
                    size = Size(bodyW, rectHeight)
                )
            }

            // 5. EMA 9 & EMA 21 overlays
            if (indicators != null && indicators.ema9Series.size >= count && indicators.ema21Series.size >= count) {
                val ema9Slice = indicators.ema9Series.takeLast(count)
                val ema21Slice = indicators.ema21Series.takeLast(count)

                val p9 = Path()
                val p21 = Path()
                ema9Slice.forEachIndexed { idx, v ->
                    val x = idx * slotW + slotW / 2f
                    val y = priceToY(v)
                    if (idx == 0) p9.moveTo(x, y) else p9.lineTo(x, y)
                }
                ema21Slice.forEachIndexed { idx, v ->
                    val x = idx * slotW + slotW / 2f
                    val y = priceToY(v)
                    if (idx == 0) p21.moveTo(x, y) else p21.lineTo(x, y)
                }
                drawPath(p9, color = CyberColors.CyberCyan, style = Stroke(width = 2.2f))
                drawPath(p21, color = CyberColors.WarningAmber, style = Stroke(width = 2.2f))
            }

            // 6. Live last price horizontal marker
            val lastClose = visibleCandles.last().close
            val lastY = priceToY(lastClose)
            drawLine(
                color = CyberColors.TextPrimary.copy(alpha = 0.55f),
                start = Offset(0f, lastY),
                end = Offset(w, lastY),
                strokeWidth = 1.2f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(5f, 5f))
            )

            // 7. Animated Scanning Beam Overlay during AI analysis
            if (isScanning) {
                val scanX = w * scanRatio
                drawRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            CyberColors.NeonGreen.copy(alpha = 0.35f),
                            CyberColors.NeonGreen.copy(alpha = 0.05f)
                        ),
                        startX = (scanX - 48f).coerceAtLeast(0f),
                        endX = (scanX + 12f).coerceAtMost(w)
                    ),
                    topLeft = Offset((scanX - 48f).coerceAtLeast(0f), 0f),
                    size = Size(60f, h)
                )
                drawLine(
                    color = CyberColors.NeonGreen,
                    start = Offset(scanX, 0f),
                    end = Offset(scanX, h),
                    strokeWidth = 2.5f
                )
            }
        }

        // Right-side price scale labels + EMA legend
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 6.dp, top = 8.dp, bottom = 8.dp)
                .height(220.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.End
        ) {
            Text(
                text = Formatters.formatPrice(maxPrice, priceDecimals),
                style = MaterialTheme.typography.labelSmall,
                color = CyberColors.TextMuted
            )
            Text(
                text = Formatters.formatPrice(visibleCandles.last().close, priceDecimals),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = CyberColors.NeonGreen,
                modifier = Modifier
                    .background(CyberColors.ElevatedSurface, RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            )
            Text(
                text = Formatters.formatPrice(minPrice, priceDecimals),
                style = MaterialTheme.typography.labelSmall,
                color = CyberColors.TextMuted
            )
        }

        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("EMA9", style = MaterialTheme.typography.labelSmall, color = CyberColors.CyberCyan)
            Text("EMA21", style = MaterialTheme.typography.labelSmall, color = CyberColors.WarningAmber)
            Text("BB20", style = MaterialTheme.typography.labelSmall, color = CyberColors.NeonGreen.copy(alpha = 0.7f))
        }
    }
}
