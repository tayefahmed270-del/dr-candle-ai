package com.drcandle.ai.scanner

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import com.drcandle.ai.utils.TerminalLogger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class ScreenCaptureManager(private val context: Context) {

    suspend fun captureSingleFrameWithRetries(
        resultCode: Int,
        resultData: Intent,
        maxAttempts: Int = 3
    ): Result<Bitmap> = withContext(Dispatchers.Default) {
        val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        var projection: MediaProjection? = null
        var virtualDisplay: VirtualDisplay? = null
        var imageReader: ImageReader? = null

        try {
            projection = projectionManager.getMediaProjection(resultCode, resultData)
                ?: return@withContext Result.failure(IllegalStateException("MediaProjection returned null. Re-grant screen capture permission."))

            val metrics = context.resources.displayMetrics
            // Scale down width <= 960px to keep payload crisp and well under Gemini Vision limits
            val scale = if (metrics.widthPixels > 960) 960f / metrics.widthPixels else 1f
            val width = (metrics.widthPixels * scale).toInt().coerceAtLeast(320)
            val height = (metrics.heightPixels * scale).toInt().coerceAtLeast(480)
            val density = metrics.densityDpi

            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            val callback = object : MediaProjection.Callback() {
                override fun onStop() {
                    TerminalLogger.info("SCANNER", "MediaProjection stopped")
                }
            }
            projection.registerCallback(callback, Handler(Looper.getMainLooper()))

            virtualDisplay = projection.createVirtualDisplay(
                "DrCandleScannerDisplay",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.surface,
                null,
                null
            )

            // Wait briefly for compositor to render a frame, retrying up to maxAttempts
            var capturedBitmap: Bitmap? = null
            for (attempt in 1..maxAttempts) {
                delay(280L * attempt)
                val image: Image? = imageReader.acquireLatestImage()
                if (image != null) {
                    try {
                        capturedBitmap = imageToBitmap(image, width, height)
                        if (capturedBitmap != null) {
                            TerminalLogger.info("SCANNER", "Captured screen frame ${capturedBitmap.width}x${capturedBitmap.height} on attempt $attempt")
                            break
                        }
                    } finally {
                        image.close()
                    }
                } else {
                    TerminalLogger.warn("SCANNER", "Capture frame buffer empty (attempt $attempt/$maxAttempts)")
                }
            }

            if (capturedBitmap != null) {
                Result.success(capturedBitmap)
            } else {
                Result.failure(IllegalStateException("Screen capture frame buffer was empty after $maxAttempts attempts."))
            }
        } catch (e: Exception) {
            TerminalLogger.err("SCANNER", "MediaProjection capture failed: ${e.localizedMessage}")
            Result.failure(e)
        } finally {
            runCatching { virtualDisplay?.release() }
            runCatching { imageReader?.close() }
            runCatching { projection?.stop() }
        }
    }

    private fun imageToBitmap(image: Image, targetWidth: Int, targetHeight: Int): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * targetWidth
        val fullWidth = targetWidth + rowPadding / pixelStride
        val rawBitmap = Bitmap.createBitmap(fullWidth, targetHeight, Bitmap.Config.ARGB_8888)
        rawBitmap.copyPixelsFromBuffer(buffer)
        return if (fullWidth != targetWidth) {
            val cropped = Bitmap.createBitmap(rawBitmap, 0, 0, targetWidth, targetHeight)
            rawBitmap.recycle()
            cropped
        } else {
            rawBitmap
        }
    }
}
