package com.drcandle.ai.market

import com.drcandle.ai.domain.AppSettings
import com.drcandle.ai.domain.Candle
import com.drcandle.ai.domain.MarketAsset
import com.drcandle.ai.domain.MarketFeedState
import com.drcandle.ai.domain.Timeframe
import kotlinx.coroutines.flow.Flow

sealed interface MarketStreamEvent {
    data class StateChanged(val state: MarketFeedState) : MarketStreamEvent
    data class CandleUpdate(val candle: Candle, val latencyMs: Long) : MarketStreamEvent
    data class HistoricalSnapshot(val candles: List<Candle>, val latencyMs: Long) : MarketStreamEvent
}

interface MarketDataProvider {
    val providerId: String
    val displayName: String
    val supportsWebSocket: Boolean

    fun supports(asset: MarketAsset, settings: AppSettings): Boolean

    suspend fun fetchHistoricalCandles(
        asset: MarketAsset,
        timeframe: Timeframe,
        limit: Int,
        settings: AppSettings
    ): Result<Pair<List<Candle>, Long>>

    fun streamMarketData(
        asset: MarketAsset,
        timeframe: Timeframe,
        settings: AppSettings
    ): Flow<MarketStreamEvent>
}
