package com.drcandle.ai.market

import com.drcandle.ai.domain.AppSettings
import com.drcandle.ai.domain.Candle
import com.drcandle.ai.domain.MarketAsset
import com.drcandle.ai.domain.MarketFeedState
import com.drcandle.ai.domain.Timeframe
import com.drcandle.ai.network.NetworkModule
import com.drcandle.ai.utils.TerminalLogger
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

/**
 * Supports authorized custom OTC data feeds configured by the user in Settings.
 * Never fabricates or simulates Quotex OTC prices when no authorized endpoint exists.
 */
class CustomOtcFeedProvider : MarketDataProvider {
    override val providerId: String = "custom_otc_feed"
    override val displayName: String = "Authorized OTC Endpoint"
    override val supportsWebSocket: Boolean = false

    override fun supports(asset: MarketAsset, settings: AppSettings): Boolean = asset.isOtc

    override suspend fun fetchHistoricalCandles(
        asset: MarketAsset,
        timeframe: Timeframe,
        limit: Int,
        settings: AppSettings
    ): Result<Pair<List<Candle>, Long>> = withContext(Dispatchers.IO) {
        val baseUrl = settings.customOtcFeedUrl.trim()
        if (baseUrl.isEmpty()) {
            return@withContext Result.failure(
                UnsupportedOperationException(
                    "Quotex OTC prices are proprietary and not provided by public market APIs. Configure an authorized OTC feed URL in Settings or select a live Crypto/Forex/Gold asset."
                )
            )
        }

        val startMs = System.currentTimeMillis()
        try {
            val sep = if (baseUrl.contains("?")) "&" else "?"
            val url = "${baseUrl}${sep}symbol=${asset.symbol}&timeframe=${timeframe.code}&limit=$limit"
            val request = Request.Builder().url(url).get().build()
            NetworkModule.okHttpClient.newCall(request).execute().use { response ->
                val latency = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Authorized OTC feed HTTP ${response.code}"))
                }
                val body = response.body?.string().orEmpty()
                val jsonArray = if (body.trim().startsWith("[")) {
                    JSONArray(body)
                } else {
                    JSONObject(body).optJSONArray("candles") ?: JSONArray()
                }
                val candles = mutableListOf<Candle>()
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    candles.add(
                        Candle(
                            openTimeMs = obj.optLong("time", System.currentTimeMillis()),
                            open = obj.getDouble("open"),
                            high = obj.getDouble("high"),
                            low = obj.getDouble("low"),
                            close = obj.getDouble("close"),
                            volume = obj.optDouble("volume", 0.0),
                            isClosed = obj.optBoolean("closed", true)
                        )
                    )
                }
                if (candles.isEmpty()) {
                    return@withContext Result.failure(IllegalStateException("Authorized OTC feed returned 0 candles"))
                }
                Result.success(candles.sortedBy { it.openTimeMs } to latency)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            TerminalLogger.err("OTC_FEED", "Failed fetching authorized OTC feed: ${e.localizedMessage}")
            Result.failure(e)
        }
    }

    override fun streamMarketData(
        asset: MarketAsset,
        timeframe: Timeframe,
        settings: AppSettings
    ): Flow<MarketStreamEvent> = flow {
        val baseUrl = settings.customOtcFeedUrl.trim()
        if (baseUrl.isEmpty()) {
            val limitation = "Quotex OTC feed unavailable: Quotex does not offer a public authorized OTC API. Simulated prices are disabled. Select BTC/USDT, ETH/USDT, PAXG Gold, or configure an authorized OTC endpoint in Settings."
            TerminalLogger.warn("OTC_LIMIT", limitation)
            emit(MarketStreamEvent.StateChanged(MarketFeedState.UnsupportedSource(displayName, limitation)))
            return@flow
        }

        emit(MarketStreamEvent.StateChanged(MarketFeedState.Connecting(displayName)))
        while (currentCoroutineContext().isActive) {
            fetchHistoricalCandles(asset, timeframe, 100, settings)
                .onSuccess { (candles, latency) ->
                    emit(MarketStreamEvent.HistoricalSnapshot(candles, latency))
                    emit(
                        MarketStreamEvent.StateChanged(
                            MarketFeedState.LiveRestFallback(displayName, "Authorized OTC endpoint active", System.currentTimeMillis())
                        )
                    )
                }
                .onFailure { err ->
                    emit(MarketStreamEvent.StateChanged(MarketFeedState.Error(displayName, err.localizedMessage ?: "OTC feed error")))
                }
            delay(5_000L)
        }
    }.flowOn(Dispatchers.IO)
}
