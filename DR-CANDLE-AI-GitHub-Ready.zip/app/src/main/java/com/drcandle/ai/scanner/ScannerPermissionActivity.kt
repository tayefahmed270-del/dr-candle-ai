package com.drcandle.ai.scanner

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.drcandle.ai.services.FloatingScannerService
import com.drcandle.ai.utils.TerminalLogger

class ScannerPermissionActivity : ComponentActivity() {

    private val captureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            TerminalLogger.info("SCANNER", "MediaProjection consent granted by user")
            val serviceIntent = Intent(this, FloatingScannerService::class.java).apply {
                action = FloatingScannerService.ACTION_EXECUTE_SCAN
                putExtra(FloatingScannerService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(FloatingScannerService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        } else {
            TerminalLogger.warn("SCANNER", "MediaProjection consent denied by user")
            val cancelIntent = Intent(this, FloatingScannerService::class.java).apply {
                action = FloatingScannerService.ACTION_SCAN_CANCELLED
            }
            startService(cancelIntent)
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }
}
